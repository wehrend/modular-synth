// types.ts
// Zentrale Typdefinitionen — die "Sprache", die UI und Audio-Engine teilen.
// Bewusst `type`-Aliase, keine Interfaces: React Flows Node<TData> verlangt
// `TData extends Record<string, unknown>`, und nur Typ-Aliase erfüllen das.

import type { Node } from "@xyflow/react";

export const WAVEFORMS = ["sine", "triangle", "sawtooth", "square"] as const;

export type Waveform = (typeof WAVEFORMS)[number];

export type OscData = {
  frequency: number;
  waveform: Waveform;
  running: boolean;
  cvAmount: number;
};

export type OutData = {
  volume: number; // dB
  muted: boolean;
};

export const MIXER_CHANNELS = ["ch1", "ch2", "ch3"] as const;
export type MixerChannel = (typeof MIXER_CHANNELS)[number];

export type MixerData = Record<MixerChannel, number> & {
  master: number; // 0–1
};

export type FilterType = "lowpass" | "highpass" | "bandpass";

export type VcfData = {
  filterType: FilterType;
  cutoff: number; // Hz
  resonance: number; // Q
  cutoffAmount: number; // Mod-Hub in Hz (0–5000)
  resonanceAmount: number; // Mod-Hub in Q (0–10)
};

export type VcfFlowNode = Node<VcfData, "vcf">;

export type EnvelopeData = {
  attack: number; // Sekunden
  decay: number; // Sekunden
  sustain: number; // Pegel 0–1
  release: number; // Sekunden
};

export type RingModData = Record<string, never>; // keine eigenen Regler

export type RingModFlowNode = Node<RingModData, "ringmod">;

export type WaspData = {
  cutoff: number;
  resonance: number;
  drive: number;
  cutoffAmount: number;
};

export type WaspFlowNode = Node<WaspData, "wasp">;

export type OscFlowNode = Node<OscData, "osc">;
export type MixerFlowNode = Node<MixerData, "mixer">;
export type OutFlowNode = Node<OutData, "out">;
export type EnvelopeFlowNode = Node<EnvelopeData, "envelope">;

export type LfoData = {
  rate: number; // Hz, 0.05–20
  waveform: Waveform; // dieselbe Konstante wie beim VCO!
};

export type LfoFlowNode = Node<LfoData, "lfo">;

export type NoiseData = {
  whiteVolume: number;
  pinkVolume: number;
  brownVolume: number;
};

export type NoiseFlowNode = Node<NoiseData, "noise">;
// -> in AppNode, AudioNodeInit, NodePatch aufnehmen, wie gewohnt

export type VcaData = {
  gain: number;
};
export type VcaFlowNode = Node<VcaData, "vca">;
// -> in AppNode, AudioNodeInit, NodePatch aufnehmen

export type SequencerData = {
  steps: number; // Frequenzen pro Step
  bpm: number;
  running: boolean;
  cvValues: number[];
};

export type SequencerFlowNode = Node<SequencerData, "sequencer">;

export type SamplerData = {
  recording: boolean;
  hasSample: boolean; // reiner UI-Zustand: gibt es schon eine Aufnahme?
  playbackRate: number; // Pitch/Geschwindigkeit der Wiedergabe
  gain: number;
  sampleUrl: string | null;
};

export type SamplerFlowNode = Node<SamplerData, "sampler">;

export type VocoderAnalysisData = {
  sensitivity: number; // Follower-Glättungszeit in Sekunden (0.005–0.2)
};

export type VocoderAnalysisFlowNode = Node<
  VocoderAnalysisData,
  "vocoderAnalysis"
>;

export type VocoderSynthData = {
  level: number; // Ausgangspegel-Faktor, da die Summe der Bänder leise ist
};

export type VocoderSynthFlowNode = Node<VocoderSynthData, "vocoderSynth">;

export type VoicedUnvoicedData = {
  gain: number; // Vorverstärkung des Sprachsignals
  trebleBoost: number; // Höhenanhebung in dB, verbessert die Sprachverständlichkeit
};

export type VoicedUnvoicedFlowNode = Node<VoicedUnvoicedData, "voicedUnvoiced">;

export type EvenVcoData = {
  octave: number;
  fineTune: number;
  waveform: Waveform; // für den normalen Ausgang
  running: boolean;
  cvAmount: number;
};

export type EvenVcoFlowNode = Node<EvenVcoData, "evenvco">;

/** Diskriminierte Union aller Knoten der App. */
export type AppNode =
  | OscFlowNode
  | MixerFlowNode
  | VcfFlowNode
  | EnvelopeFlowNode
  | RingModFlowNode
  | WaspFlowNode
  | LfoFlowNode
  | NoiseFlowNode
  | VcaFlowNode
  | SequencerFlowNode
  | SamplerFlowNode
  | VocoderAnalysisFlowNode
  | VocoderSynthFlowNode
  | VoicedUnvoicedFlowNode
  | EvenVcoFlowNode
  | OutFlowNode;

/** Was die Audio-Engine zum Anlegen eines Knotens braucht. */
export type AudioNodeInit =
  | { id: string; type: "osc"; data: OscData }
  | { id: string; type: "mixer"; data: MixerData }
  | { id: string; type: "vcf"; data: VcfData }
  | { id: string; type: "envelope"; data: EnvelopeData }
  | { id: string; type: "ringmod"; data: RingModData }
  | { id: string; type: "wasp"; data: WaspData }
  | { id: string; type: "lfo"; data: LfoData }
  | { id: string; type: "noise"; data: NoiseData }
  | { id: string; type: "vca"; data: VcaData }
  | { id: string; type: "sequencer"; data: SequencerData }
  | { id: string; type: "sampler"; data: SamplerData }
  | { id: string; type: "vocoderAnalysis"; data: VocoderAnalysisData }
  | { id: string; type: "vocoderSynth"; data: VocoderSynthData }
  | { id: string; type: "voicedUnvoiced"; data: VoicedUnvoicedData }
  | { id: string; type: "evenvco"; data: EvenVcoData }
  | { id: string; type: "out"; data: OutData };

/** Partielle Parameter-Updates, wie sie von den Reglern kommen. */
export type NodePatch =
  | Partial<OscData>
  | Partial<MixerData>
  | Partial<VcfData>
  | Partial<EnvelopeData>
  | Partial<RingModData>
  | Partial<WaspData>
  | Partial<LfoData>
  | Partial<NoiseData>
  | Partial<VcaData>
  | Partial<SequencerData>
  | Partial<SamplerData>
  | Partial<VocoderAnalysisData>
  | Partial<VocoderSynthData>
  | Partial<VoicedUnvoicedData>
  | Partial<EvenVcoData>
  | Partial<OutData>;
