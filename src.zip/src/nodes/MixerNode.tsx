// MixerNode.tsx
// Drei Eingangskanäle mit eigenem Pegel, dahinter eine Master-Summe.
// Die Eingangsbuchsen (Target-Handles) sitzen gleichmäßig verteilt am
// linken Modulrand; die Kanal-Knobs liegen als Reihe im Modul. Die
// Handle-ID (ch1–ch3) landet in der Kante als `targetHandle` und sagt
// der Audio-Engine, welcher Kanal-Gain gemeint ist.

import { Handle, Position, useReactFlow, type NodeProps } from "@xyflow/react";
import { useTranslation } from "react-i18next";
import { updateAudioNode } from "../audio";
import Knob from "../components/Knob";
import {
  MIXER_CHANNELS,
  MixerChannel,
  type MixerData,
  type MixerFlowNode,
} from "../types";
import styles from "./Module.module.scss";

import * as Tone from "tone";

const RAMP = 0.04; // Sekunden — knackfreie Parameterwechsel

type MixerEntry = {
  type: "mixer";
  ins: Record<MixerChannel, Tone.Gain>;
  sum: Tone.Gain;
  out: Tone.ToneAudioNode;
};

export function createMixerNode(_id: string, data: MixerData): MixerEntry {
  // Drei Eingangskanäle mit eigenem Gain, die auf eine Summe laufen.
  // `ins` bildet Handle-IDs auf Audio-Eingänge ab (siehe connectAudio).
  const sum = new Tone.Gain(data.master ?? 0.8);
  const ins = {
    ch1: new Tone.Gain(data.ch1 ?? 0.8),
    ch2: new Tone.Gain(data.ch2 ?? 0.8),
    ch3: new Tone.Gain(data.ch3 ?? 0.8),
  };
  Object.values(ins).forEach((ch) => ch.connect(sum));
  return { type: "mixer", ins, sum, out: sum };
}

export function updateMixerNode(
  entry: MixerEntry,
  patch: Partial<MixerData>,
): void {
  const p = patch as Partial<MixerData>;
  (Object.keys(entry.ins) as MixerChannel[]).forEach((ch) => {
    const value = p[ch];
    if (value !== undefined) {
      entry.ins[ch].gain.rampTo(value, RAMP);
    }
  });
  if (p.master !== undefined) {
    entry.sum.gain.rampTo(p.master, RAMP);
  }
}

export function disposeMixerNode(node: MixerEntry) {
  Object.values(node.ins).forEach((ch) => ch.dispose());
  node.sum.dispose();
}

const asPercent = (v: number) => `${Math.round(v * 100)} %`;

export default function MixerNode({ id, data }: NodeProps<MixerFlowNode>) {
  const { t } = useTranslation();
  const { updateNodeData } = useReactFlow();

  const patch = (changes: Partial<MixerData>) => {
    updateNodeData(id, changes);
    updateAudioNode(id, changes);
  };

  return (
    <div className={styles.module}>
      <header className={styles.head}>
        <span className={styles.title}>{t("modules.mixer.title")}</span>
      </header>

      {/* Buchsenleiste: Handles gleichmäßig über die Modulhöhe verteilt.
          Bei n Kanälen liegt Buchse i bei (i+1)/(n+1) der Höhe —
          für drei Kanäle also 25 %, 50 %, 75 %. */}
      {MIXER_CHANNELS.map((ch, i) => (
        <Handle
          key={ch}
          type="target"
          position={Position.Left}
          id={ch}
          style={{ top: `${((i + 1) / (MIXER_CHANNELS.length + 1)) * 100}%` }}
        />
      ))}

      {/* Kanal-Regler nebeneinander */}
      <div className={styles.mixerKnobRow}>
        {MIXER_CHANNELS.map((ch, i) => (
          <Knob
            key={ch}
            label={t("modules.mixer.inLabel", { n: i + 1 })}
            value={data[ch]}
            min={0}
            max={1}
            step={0.01}
            format={asPercent}
            onChange={(v) => patch({ [ch]: v })}
          />
        ))}
      </div>

      <div className={styles.mixerMaster}>
        <Knob
          label={t("modules.mixer.masterLabel")}
          value={data.master}
          min={0}
          max={1}
          step={0.01}
          format={asPercent}
          onChange={(v) => patch({ master: v })}
        />
      </div>

      <Handle type="source" position={Position.Right} />
    </div>
  );
}
